import mouse

print(mouse.get_position())
