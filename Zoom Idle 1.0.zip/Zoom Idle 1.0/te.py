import pyautogui

iml = pyautogui.screenshot (region=(1830,955,100,100))
iml.save(r"C:\Users\muisc\Desktop\Zoom Idle 1.0\savedimage.png")
